let a = 1;
let b = 2;
console.log(a + b);